#include "../headers/process.h"

// Static Declarations------------------------------------------------------

// Parses an expression for Data Processing
static uint32_t parseExpressionProcessing(char *expr);

/* 
 * Returns operand2 for Data Processing
 * Sets the immeditate depending on the operand
 */
static uint32_t getOperand2(char *operand, bool *imm);

// Covers the case where address is pre-indexed without shift
static void preIndexing(char *token, bool *upBit_ptr, uint32_t *offset_ptr, bool *immBit_ptr);

// Covers the case where address is post-indexed without shift
static void postIndexing(char *token, bool *upBit_ptr, uint32_t *offset_ptr, bool *immBit_ptr);

// Covers case where address has a shifted register
static void indexingWithShift(char *token, bool *immBit_ptr, bool *upBit_ptr, uint32_t *offset_ptr);

// Converts a binary string to an int 
static int bstr_to_int(const char* str);

//--------------------------------------------------------------------------

uint32_t processDataProcessing(char *instr) {
  char *token = strtok(instr, DELIM);
  int opcode = get(&OPCODE_MAP, token);
  int operand2;
  uint32_t r1, r2;
  bool imm;
  bool done = false;
  
  // Get first register
  token = strtok(NULL, DELIM);
  if (!token) {
    fprintf(stderr, "Invalid instruction!");
    exit(EXIT_FAILURE);
  }
  r1 = getRegister(token);

  // Get second term (register or operand2)
  if (opcode == 13 || (opcode >= 8 && opcode <= 10)) {
    // Opcode is mov or CPSR setter, so term is operand2
    token = strtok(NULL, "");
    operand2 = getOperand2(token, &imm);
    done = true;
  } else {
    // Opcode is a result computer, so term is register
    token = strtok(NULL, DELIM);
    if (!token) {
      fprintf(stderr, "Invalid instruction!");
      exit(EXIT_FAILURE);
    }
    r2 = getRegister(token);
  }

  // Get third term (operand2)
  if (!done) {
    // Opcode is a result computer, so term is operand2
    token = strtok(NULL, "");
    operand2 = getOperand2(token, &imm);
    done = true;
  }
  
  //Assemble the instruction
  uint32_t instruction = 0xE0000000;  // Condition field 1110
  instruction |= imm << 25;           // Imm 
  instruction |= operand2;            // Operand2
  instruction |= opcode << 21;        // Opcode
  if (opcode == 13) {
    // Instruction is mov
    instruction |= r1 << 12;          // Destination Register
    
  } else if (opcode >= 8 && opcode <= 10) {
    // Instruction is a CPSR setter
    instruction |= r1 << 16;          // Source Register
    instruction |= 1 << 20;           // S
  } else {
    // Instruction is a result computer
    instruction |= r1 << 12;          // Destination Register
    instruction |= r2 << 16;          // Source Register
  }

  return instruction;
}

static uint32_t parseExpressionProcessing(char *expr) {
  int result;
  result = strtol(expr, NULL, 0);
  uint32_t unsignedResult = result;
  uint32_t mask = 0xFFFFFF00;
  size_t rotateAmount = 0;
  while ((unsignedResult & mask) != 0 && rotateAmount <= 15) {
    rotateLeft(&unsignedResult);
    rotateAmount++;
  }
  if (rotateAmount > 15) {
    fprintf(stderr, "Cannot represent the immediate!");
    exit(EXIT_FAILURE);
  }
  return (rotateAmount << 8) | unsignedResult;
}

uint32_t getRegister(char* reg) {
  if (reg[0] != 'r') {
    fprintf(stderr, "Invalid register!");
    exit(EXIT_FAILURE);
  }
  uint16_t r1 = atoi(reg + 1);
  checkRegisterIndex(r1);
  return r1;
}

static uint32_t getOperand2(char *operand, bool *imm) {
  // Get first term of the operand
  char *token = strtok(operand, DELIM);
  if (!token) {
    fprintf(stderr, "Invalid second operand!");
    exit(EXIT_FAILURE);
  }
  if (token[0] == '#') {
    *imm = true;
    return parseExpressionProcessing(token + 1);
  }
  if (token[0] != 'r') {
    fprintf(stderr, "Invalid second operand!");
    exit(EXIT_FAILURE);
  }
  *imm = false;
  uint32_t r1 = getRegister(token);

  // Get second term of the operand
  token = strtok(NULL, DELIM);
  if (!token) {
    return r1;
  }
  if (!contains(&SHIFT_MAP, token))  {
    fprintf(stderr, "Invalid shift type!");
    exit(EXIT_FAILURE);
  }
  uint32_t shiftType = get(&SHIFT_MAP, token);

  // Get last term of the operand
  token = strtok(NULL, DELIM);
  if (!token) {
    fprintf(stderr, "Invalid second operand!");
    exit(EXIT_FAILURE);
  }

  uint32_t shiftAmount;
  uint32_t totalShift = shiftType << 1;;
  if (token[0] == '#') {
    shiftAmount = parseExpressionProcessing(token + 1);
    totalShift |= shiftAmount << 3;
  } else if (token[0] == 'r') {
    shiftAmount = getRegister(token);
    totalShift |= 1;
    totalShift |= shiftAmount << 4;
  } else {
    fprintf(stderr, "Invalid second operand!");
    exit(EXIT_FAILURE);
  }
  return (totalShift << 4) | r1;
}

uint32_t processMultiply(char *instr) {
  uint32_t rd, rn, rs, rm;
  char *token = strtok(instr, DELIM);
  int acc = false;

  if (instr[1] == 'l')  {
    acc = true;
  }

  //Get the destination register
  token = strtok(NULL, DELIM); 
  if (!token) {
    fprintf(stderr, "Invalid instruction!");
    exit(EXIT_FAILURE);
  }
  rd = getRegister(token);

  //Get the second multiplication register
  token = strtok(NULL, DELIM);
  if (!token) {
    fprintf(stderr, "Invalid instruction!");
    exit(EXIT_FAILURE);
  }
  rm = getRegister(token);

  //Get the first multiplication register
  token = strtok(NULL, DELIM);
  if (!token) {
    fprintf(stderr, "Invalid instruction!");
    exit(EXIT_FAILURE);
  }
  rs = getRegister(token);

  if (acc) {
  //Get the accumulator register
  token = strtok(NULL, DELIM);
  if (!token) {
    fprintf(stderr, "Invalid instruction!");
    exit(EXIT_FAILURE);
  }
  rn = getRegister(token);
  }

  //Assemble the instruction
  uint32_t instruction = 0xE0000000;  // Condition field 1110
  if (acc) {
  instruction |= 1 << 21; // mla
  instruction |= rn << 12;
  }
  instruction |= rd << 16;
  instruction |= rs << 8;
  instruction |= 1 << 7;
  instruction |= 1 << 4;
  // or: instruction |= 9 << 4;
  instruction |= rm;

  return instruction;
}

static void parseNumberToOffset(char *token, uint32_t *offset_ptr) {
  if (token[1] == 'x') {//in hex format, accessing the second element is always okay as token contains at least 1 number so second character will be either sentinel character or a digit
    sscanf(token, "0x%x", offset_ptr);
  } else {//is single digit not in hex format 
    int number;
    sscanf(token, "%d", &number);
    *offset_ptr = number;
  }
}

static void preIndexing(char *token, bool *upBit_ptr, uint32_t *offset_ptr, bool *immBit_ptr) {
  token++;
  
  if (token[strlen(token) - 1] != ']') {
    fprintf(stderr, "Format of pre indexed address not supported");
    exit(EXIT_FAILURE);
  }
          
  token[strlen(token) - 1] = '\0'; //remove the close bracket

  if (token[0] == '-') {
    //is negative 
    *upBit_ptr = false;
    token++;
  } else {
    //is positive
    *upBit_ptr = true;
  }
  
  parseNumberToOffset(token, offset_ptr);

  *immBit_ptr = false;
}

static void postIndexing(char *token, bool *upBit_ptr, uint32_t *offset_ptr, bool *immBit_ptr) {
  token++;
          
  if (token[0] == '-') {
    //is negative 
    *upBit_ptr = false;
    token++;
  } else {
    //is positive 
    *upBit_ptr = true;
  }
  
  parseNumberToOffset(token, offset_ptr);

  *immBit_ptr = false;
  *upBit_ptr = true;
}

static void indexingWithShift(char *token, bool *immBit_ptr, bool *upBit_ptr, uint32_t *offset_ptr)  {
  int rm; 
  
  *immBit_ptr = true;
  
  if (token[0] == '-') {
    *upBit_ptr = false;
    token++;
  } else {
    *upBit_ptr = true;
  }
  
  rm = getRegister(token);
  token = strtok(NULL, DELIM);

  if (token != NULL) {
    //case with shift amount 
    uint32_t shiftType = get(&SHIFT_MAP, token);

    // Get last term of the operand
    token = strtok(NULL, DELIM);
    if (!token) {
      fprintf(stderr, "Invalid second operand!");
      exit(EXIT_FAILURE);
    }
    uint32_t shiftAmount;
    uint32_t totalShift = shiftType << 1;;
    if (token[0] == '#') {
      shiftAmount = parseExpressionProcessing(token + 1);
      totalShift |= shiftAmount << 3;
    } else if (token[0] == 'r') {
      shiftAmount = getRegister(token);
      totalShift |= 1;
      totalShift |= shiftAmount << 4;
    } else {
      fprintf(stderr, "Invalid second operand!");
      exit(EXIT_FAILURE);
    }
    *offset_ptr = (totalShift << 4) | rm;
  } else {
    //case without shift amount
    *offset_ptr = rm;
  }
}

static uint32_t convertToMov(uint32_t rd, uint32_t number) {
  int maxSizeOfString = 14; 
  /*
    There are 8 actual characters plus 1 terminal character and 2 numbers 
    The max length of number 1 is 2 as we can only have it specifying two digit register indices 
    The max length of number 2 is 3 as 0xFF is 255 which is 3 digits
    so 8 + 1 + 2 + 3 = 14
  */
  char str[maxSizeOfString];

  snprintf(str, maxSizeOfString,  "mov r%d, #%d", rd, number);

  return processDataProcessing(str);
}

static void numericConstantForm(linkedList *list, uint32_t number, uint32_t *rn_ptr, uint32_t *offset_ptr, uint32_t *lastAddress, uint32_t address, bool *immBit_ptr, bool *preBit_ptr, bool *upBit_ptr) {
  add(list, number);//put value of expression in list to be put at end of assembled program

  *rn_ptr = 15; // PC is the base register

  *offset_ptr = *lastAddress - address - 8;//8 for the pipeline being 8 bytes ahead of the current instruction

  *lastAddress += 4; // move the address along 4 bytes to make space for the next instruction

  *immBit_ptr = false; //offset is a number not a shifted register
  *preBit_ptr = true;
  *upBit_ptr = true; // adding the offset because the last index from the current is positive
}

uint32_t processDataTransfer(char *instr, uint32_t address, uint32_t *lastAddress, linkedList *list) {
  uint32_t instruction = 0;
  uint32_t cond = 0xE; //1111
  uint32_t bits27n26 = 01;

  bool immBit, preBit, upBit, loadBit;
  uint32_t rn, rd, offset;

  char *token = strtok(instr, DELIM);

  if (!token) {
    fprintf(stderr, "No instruction loaded");
    exit(EXIT_FAILURE);
  }
  if (!strcmp(token, "ldr")) {
    loadBit = true;
  } else if (!strcmp(token, "str")) {
    loadBit = false;
  } else {
    fprintf(stderr, "Invalid instruction type in processDataTransfer");
    exit(EXIT_FAILURE);
  }

  token = strtok(NULL, DELIM);
  rd = getRegister(token);
  token = strtok(NULL, DELIM);

  if (token[0] == '=') {
    if (loadBit) {
      token++;

      uint32_t number;
      //might have to change this to support a single digit
      sscanf(token, "0x%x", &number);

      if (number <= 0xFF) {
        return convertToMov(rd, number);
      }
      numericConstantForm(list, number, &rn, &offset, lastAddress, address, &immBit, &preBit, &upBit);
    } else {
      fprintf(stderr, "Numeric constant form not allowed for store");
      exit(EXIT_FAILURE);
    }
  } else {
    if (token[0] != '[') {
      fprintf(stderr, "Format of address not supported");
      exit(EXIT_FAILURE);
    }

    token++;
  
    if (token[strlen(token) - 1] == ']') {
      token[strlen(token) - 1] = '\0'; //removing the last character

      rn = getRegister(token);

      if ((token = strtok(NULL, DELIM)) == NULL) {//nothing else after the close bracket
        offset = 0;
        immBit = false;
        preBit = true;
        upBit = true; //irrelevant as x +/- 0 = x but still needs to be initialised
      } else {//Post indexing
        preBit = false;

        if (token[0] == '#') {
          postIndexing(token, &upBit, &offset, &immBit);
        } else {//optional post indexing
          indexingWithShift(token, &immBit, &upBit, &offset);
        }
      }
    } else {//pre indexing
      preBit = true;
      
      rn = getRegister(token);
      token = strtok(NULL, DELIM);

      if (token == 0x0) {
        fprintf(stderr, "Format of pre indexed address not supported");
        exit(EXIT_FAILURE);
      } else if (token[0] == '#') {
        preIndexing(token, &upBit, &offset, &immBit);
      } else {
        //optional pre indexing part
        indexingWithShift(token, &immBit, &upBit, &offset);
      }
    }
  }

  instruction |= cond << 28;
  instruction |= bits27n26 << 26;
  instruction |= immBit << 25;
  instruction |= preBit << 24;
  instruction |= upBit << 23;
  instruction |= loadBit << 20;
  instruction |= rn << 16;
  instruction |= rd << 12;
  instruction |= offset;
  
  return instruction;
}

uint32_t processBranch(char *instr, map *labels, uint32_t address) {
  char *token = strtok(instr, DELIM);
  token++;   // first char is always 'b'
  int cond = get(&CONDITION_MAP, token);
  uint32_t target;
  int32_t offset;

  // get target address
  token = strtok(NULL, DELIM);
  if (!token) {
    fprintf(stderr, "Invalid instruction!");
    exit(EXIT_FAILURE);
  }
  
  if (*token == '#'){ // immediate target
    target = bstr_to_int(token + 1);
  }
  else{ // labelled target
    target = get(labels, token);
  }

// generate offset
  offset = target - address - 8; // take into account offset of PC
  offset = offset >> 2;
  offset = offset & 0xFFFFFF; //masks top 8 bits

  // assemble instruction 
  uint32_t inst = cond << 28;  // set cond
  inst |= 5 << 25;            // set constants
  inst |= offset;             // set offset
  return inst;
}

//converts a binary string to a decimal number
static int bstr_to_int(const char* str){
  int val = 0;
  while (*str != '\0'){
    val = 2 * val + (*str++ - '0');
  }
  return val;
}

uint32_t processShift(char *instr) {
  // Get the shift type
  char *token = strtok(instr, DELIM);
  int shiftType = get(&SHIFT_MAP, token);  

  // Get register
  token = strtok(NULL, DELIM);
  if (!token) {
    fprintf(stderr, "Invalid instruction!");
    exit(EXIT_FAILURE);
  }
  uint32_t reg = getRegister(token); 

  // Get the immediate
  token = strtok(NULL, DELIM);
  uint32_t imm;
  if (token[0] != '#') {
    fprintf(stderr, "Invalid immediate!");
    exit(EXIT_FAILURE);
  }

  imm = strtol(token + 1, NULL, 0);
  if (imm > (1 << 5)) {
    fprintf(stderr, "Immediate cannot be represented!");
    exit(EXIT_FAILURE);
  }

  //Assemble the instruction
  uint32_t instruction = 0xE0000000;  // Condition field 1110
  instruction |= 13 << 21;            // mov opcode
  instruction |= reg << 12;           // Destination register
  instruction |= reg;                 // Rm
  instruction |= shiftType << 5;      // Shift type
  instruction |= imm << 7;            // Shift amount

  return instruction;
}
