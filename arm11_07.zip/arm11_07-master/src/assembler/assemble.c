#include "../headers/assemble.h"

int main(int argc, char **argv) {
  if (argc != 3) {
    fprintf(stderr, "You have to provide an assembly file and a destination!");
    exit(EXIT_FAILURE);
  }

  FILE *assembly = fopen(argv[1], "r");
  if (!assembly) {
    fprintf(stderr, "The file cannot be read!");
    exit(EXIT_FAILURE);
  }

  FILE *bin = fopen(argv[2], "wb");
  if (!bin) {
    fprintf(stderr, "The binary file cannot be created!");
    exit(EXIT_FAILURE);
  }

  uint32_t lastAddress;
  map labels = makeLabelMap(assembly, &lastAddress);
  createAllMaps();

  makeBinaryFile(assembly, bin, &labels, &lastAddress);

  clear(&labels);
  clearAllMaps();
  fclose(bin);
  fclose(assembly);
  return EXIT_SUCCESS;
}

map makeLabelMap(FILE *file, uint32_t *lastAddress) {
  uint32_t address = 0;
  char buffer[LINE_LENGTH + 1];
  map m = newMap();

  while (fgets(buffer, LINE_LENGTH, file)) {
    size_t length = strlen(buffer);
    if (buffer[length - 2] == ':') {
      char *key = malloc(length - 1);
      strncpy(key, buffer, length - 2);
      put(&m, key, address);
      free(key);
    } else {
      if (buffer[0] != '\n') {
        address += 4;
      }
    }
  }
  *lastAddress = address;
  rewind(file);
  return m;
}

void makeBinaryFile(FILE *assembly, FILE *bin, map *labels, uint32_t *lastAddress) {
  char buffer[LINE_LENGTH + 1];
  uint32_t address = 0;

  struct linkedList list = {NULL, 0};

  while (fgets(buffer, LINE_LENGTH, assembly)) {
    size_t length = strlen(buffer);
    if (buffer[length - 2] == ':') {
      continue;
    }

    // Remove the '\n'
    buffer[strlen(buffer)-1] = 0;

    // Find the instruction
    int firstSpace;
    for (firstSpace = 0; buffer[firstSpace] != ' '; firstSpace++);
    char *instr = malloc(firstSpace + 1);
    strncpy(instr, buffer, firstSpace);
    instr[firstSpace] = 0;

    if (!contains(&INSTRUCTION_MAP, instr)) {
      free(instr);
      continue;
    }

    uint32_t instruction;
    switch(get(&INSTRUCTION_MAP, instr)) {
      case DATA_PROCESSING:
        instruction = processDataProcessing(buffer);
        break;
      case MULTIPLY:
        instruction = processMultiply(buffer);
        break;
      case DATA_TRANSFER:
        instruction = processDataTransfer(buffer, address, lastAddress, &list);
        break;
      case BRANCH:
        instruction = processBranch(buffer, labels, address);
        break;
      case SHIFT:
        instruction = processShift(buffer);
        break;
      case HALT:
        instruction = 0;
        break;
      default:
        fprintf(stderr, "Not a valid instruction!");
        exit(EXIT_FAILURE);   
    }
    address += 4;
    free(instr);
    fwrite(&instruction, 1, sizeof(uint32_t), bin);
  }

  uint32_t item;
  int listSize = list.size;
  for (int i = 0; i < listSize; i++)
  {
    item = getItem(&list);
    fwrite(&item, 1, sizeof(uint32_t), bin);
  }
}
