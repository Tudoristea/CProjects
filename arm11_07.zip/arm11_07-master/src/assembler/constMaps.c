#include "../headers/constMaps.h"

// Static Declarations------------------------------------------------------

// Returns a map with all the instructions
static map instructionMap(void);

// Returns a map with all the opcodes
static map opcodeMap(void);

// Returns a map with all the conditions
static map conditionMap(void);

// Returns a map with all the shift
static map shiftMap(void);

//--------------------------------------------------------------------------

map instructionMap(void) {
  map m = newMap();

  // DATA PROCESSING
  put(&m, "add", DATA_PROCESSING);
  put(&m, "sub", DATA_PROCESSING);
  put(&m, "rsb", DATA_PROCESSING);
  put(&m, "and", DATA_PROCESSING);
  put(&m, "eor", DATA_PROCESSING);
  put(&m, "orr", DATA_PROCESSING);
  put(&m, "mov", DATA_PROCESSING);
  put(&m, "tst", DATA_PROCESSING);
  put(&m, "teq", DATA_PROCESSING);
  put(&m, "cmp", DATA_PROCESSING);

  // MULTIPLY
  put(&m, "mul", MULTIPLY);
  put(&m, "mla", MULTIPLY);

  // SINGLE DATA TRANSFER
  put(&m, "ldr", DATA_TRANSFER);
  put(&m, "str", DATA_TRANSFER);

  // BRANCH
  put(&m, "beq", BRANCH);
  put(&m, "bne", BRANCH);
  put(&m, "bge", BRANCH);
  put(&m, "blt", BRANCH);
  put(&m, "bgt", BRANCH);
  put(&m, "ble", BRANCH);
  put(&m, "b", BRANCH);

  // SPECIAL
  put(&m, "lsl", SHIFT);
  put(&m, "lsr", SHIFT);
  put(&m, "asr", SHIFT);
  put(&m, "ror", SHIFT);
  put(&m, "andeq", HALT);

  return m;
}

map opcodeMap(void) {
  map m = newMap();

  put(&m, "and", 0);
  put(&m, "eor", 1);
  put(&m, "sub", 2);
  put(&m, "rsb", 3);
  put(&m, "add", 4);
  put(&m, "orr", 12);
  put(&m, "mov", 13);
  put(&m, "tst", 8);
  put(&m, "teq", 9);
  put(&m, "cmp", 10);

  return m;
}

map conditionMap(void) {
  map m = newMap();

  put(&m, "eq", 0);
  put(&m, "ne", 1);
  put(&m, "ge", 10);
  put(&m, "lt", 11);
  put(&m, "gt", 12);
  put(&m, "le", 13);
  put(&m, "al", 14);
  put(&m, "", 14);

  return m;
}

map shiftMap(void) {
  map m = newMap();

  put(&m, "lsl", 0);
  put(&m, "lsr", 1);
  put(&m, "asr", 2);
  put(&m, "ror", 3);

  return m;
}

void createAllMaps(void) {
  INSTRUCTION_MAP = instructionMap();
  OPCODE_MAP = opcodeMap();
  SHIFT_MAP = shiftMap();
  CONDITION_MAP = conditionMap();
}

void clearAllMaps(void) {
  clear(&INSTRUCTION_MAP);
  clear(&OPCODE_MAP);
  clear(&SHIFT_MAP);
  clear(&CONDITION_MAP);
}
