#include "../headers/map.h"

map newMap(void) {
  map m = {NULL, 0};
  return m;
}

bool contains(const map *m, const char *key) {
  return lookUp(m, key) != NULL;
}

mapNode* lookUp(const map *m, const char *key) {
  mapNode *node = m->head;
  while (node) {
    if (!strcmp(node->key, key)) {
      return node;
    }
    node = node->next;
  }
  return NULL;
}

int get(const map *m, const char *key) {
  mapNode* node = lookUp(m, key);
  if (node) {
    return node->value; 
  }
  fprintf(stderr, "The key is not part of the map!");
  exit(EXIT_FAILURE);
}

void put(map *m, const char* key, int value) {
  mapNode *node = lookUp(m, key);
  if (node) {
    node->value = value;
  } else {
    mapNode *oldHead = m->head;
    mapNode *newHead = malloc(sizeof(mapNode));

    char *newKey = calloc(strlen(key) + 1, sizeof(char));
    strcpy(newKey, key);
    *newHead = (mapNode) {oldHead, newKey, value};
    
    m->head = newHead;
    m->size++;
  }
}

void printMap(const map *m) {
  mapNode *curr = m->head;
  puts("Key\tValue");
  while (curr) {
    printf("%s\t%d\n", curr->key, curr->value);
    curr = curr->next;
  }
}

void clear(map *m) {
  mapNode *curr = m->head;
  while (curr) {
    free(curr->key);
    mapNode *next = curr->next;
    free(curr);
    curr = next;
  }
}

int smallerValues(const map *m, int x) {
  mapNode *curr = m->head;
  int result = 0;
  while (curr) {
    if (curr->value < x) {
      result++;
    }
    curr = curr->next;
  }
  return result;
}
