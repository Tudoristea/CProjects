#include "../headers/utils.h"

uint32_t getBits(uint32_t instruction, int firstBit, int lastBit) {
  if (lastBit < firstBit) {
    return 0;
  }
  uint32_t m = 0;
  for (int i = firstBit; i <= lastBit; i++) {
    uint32_t bit = 1u << i;
    m |= bit;
  }
  instruction &= m;
  return instruction >> firstBit;
}

uint32_t getCond(uint32_t instruction) {
 return getBits(instruction, 28, 31);
}

uint32_t getId(uint32_t instruction) {
  return getBits(instruction, 26, 27);
}

bool isMul(uint32_t instruction) {
  if (getBits(instruction, 22, 27) == 0 && getBits(instruction, 4, 7) == 9) {
    return true;
  }
  return false;
}

uint32_t convertToLittleEndian(uint32_t instruction) {
  //byte 3 to byte 0, move byte 1 to byte 2, move byte 2 to byte 1, byte 0 to byte 3
  return ((instruction >> 24) & 0xFF) | ((instruction << 8) & 0xFF0000) | ((instruction >> 8) & 0xFF00) | ((instruction << 24) & 0xFF000000);
}

int rotateRight(uint32_t value, uint32_t rotation) {
  int shifted = value >> rotation;
  int rotBits;
  if (rotation) {
    rotBits = value << (32 - rotation);
  } else {
    rotBits = 0;
  }
  return shifted | rotBits;
}

void checkRegisterIndex(uint32_t index) {
  if (index > 12) {
    fprintf(stderr, "Not a valid register index!");
    exit(EXIT_FAILURE);
  }
}

int shift(int value, uint32_t shiftAmount, uint32_t shiftType, int *carry) {
  uint32_t unsValue = value;
  switch (shiftType) {
    case 0: // lsl
      unsValue <<= shiftAmount;
      value = unsValue;
      if (shiftAmount > 0) {
        *carry = getBits(unsValue, 32 - shiftAmount, 32 - shiftAmount);
      } else {
        *carry = 0;
      }
      return value;
    case 1: // lsr
      unsValue >>= shiftAmount;
      value = unsValue;
      if (shiftAmount > 0) {
        *carry = getBits(unsValue, shiftAmount - 1, shiftAmount - 1);
      } else {
        *carry = 0;
      }
      return value;
    case 2: // asr
      if (shiftAmount > 0) {
        *carry = getBits(unsValue, shiftAmount - 1, shiftAmount - 1);
      } else {
        *carry = 0;
      }
      return value >> shiftAmount;
    case 4: // ror
      if (shiftAmount > 0) {
          *carry = getBits(unsValue, shiftAmount - 1, shiftAmount - 1);
      } else {
          *carry = 0;
      }
      return rotateRight(value, shiftAmount);
    default:  
      fprintf(stderr, "Not a valid type of shift!");
      exit(EXIT_FAILURE);
  }
}

void printState(const machine *state) {
  puts("Registers:");
  for (int i = 0; i < GEN_REGISTERS; i++) {
    if (i < 10) {
      printf("$%d  : %10d (0x%08x)\n", i, state->rg[i], state->rg[i]);
    } else {
      printf("$%d : %10d (0x%08x)\n", i, state->rg[i], state->rg[i]);
    }
  }
  printf("PC  : %10u (0x%08x)\n", state->pc, state->pc);
  printf("CPSR: %10d (0x%08x)\n", transformCPSR(state), transformCPSR(state));
  printMemory(state->memory);
}

int transformCPSR(const machine *state) {
  int result = 0;
  result |= ((unsigned int) state->neg << 31);
  result |= ((unsigned int) state->zero << 30);
  result |= ((unsigned int) state->carry << 29);
  result |= ((unsigned int) state->overflow << 28);
  return result;
}

void printMemory(const int memory[]) {
  puts("Non-zero memory:");
   for(int i = 0; i < MEMORY_WORDS; i++) {
     if(memory[i]) {
       printf("0x%08x: 0x%08x\n", 4 * i, convertToLittleEndian(memory[i]));
     }
   }
}

void rotateLeft(uint32_t *value) {
  uint32_t firstBits = *value & 0xC0000000;
  firstBits >>= 30;
  *value <<= 2;
  *value |= firstBits;
}