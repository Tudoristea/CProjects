#include "../headers/list.h"

void add(linkedList *list, int item) {
  node *newNode = malloc(sizeof(node));
    
  newNode->val = item;
  newNode->next = NULL;
    
  if (list->size == 0) {   
    list->head = newNode;
  } else {
    node *current = list->head;
    while (current->next != NULL) {
      current = current->next;
    }
    current->next = newNode;
  }
  list->size++;
}

int getItem(linkedList *list) {
  node *newNode = list->head;
  int item = newNode->val;
  list->head = list->head->next;

  free(newNode);
  list->size--;
    
  return item;
}
