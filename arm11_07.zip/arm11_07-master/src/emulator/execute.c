#include "../headers/execute.h"

void execute(decodedInstr instr, machine *state, optInstr *fetched, decodedInstr *decoded) {
  if (checkFlags(instr.instruction, state)) {
    switch(instr.type) {
      case DATA_PROCESSING:
        executeProcessing(instr.instruction, state);
        break;
      case MULTIPLY:
        executeMultiply(instr.instruction, state);
        break;
      case DATA_TRANSFER:
        executeTransfer(instr.instruction, state);
        break;
      case BRANCH:
        executeBranch(instr.instruction, state, fetched, decoded);
        break;
      default:
        fprintf(stderr, "Not a valid instruction!");
        exit(EXIT_FAILURE);  
    }
  }
}

void executeProcessing(uint32_t instr, machine *state) {
  uint32_t imm = getBits(instr, 25, 25);
  int operand2;
  int carry;
  if (imm) {
    operand2 = getImmediateProcessing(getBits(instr, 0, 11), &carry);
  } else {
    operand2 = getRegisterProcessing(getBits(instr, 0, 11), state, &carry);
  }
  uint32_t opcode = getBits(instr, 21, 24);

  uint32_t rnIndex = getBits(instr, 16, 19);
  checkRegisterIndex(rnIndex);
  int rn = state->rg[rnIndex];

  uint32_t rdIndex = getBits(instr, 12, 15);
  checkRegisterIndex(rdIndex);
  
  int result;
  switch (opcode) {
    case 0: // and
      result = rn & operand2;
      state->rg[rdIndex] = result;
      break;
    case 1: // eor
      result = rn ^ operand2;
      state->rg[rdIndex] = result;
      break;
    case 2: // sub
      result = rn - operand2;
      state->rg[rdIndex] = result;
      if (rn < operand2) {
        carry = 0;
      } else {
        carry = 1;
      }
      break;
    case 3: // rsb
      result = operand2 - rn;
      state->rg[rdIndex] = result;
      break;
    case 4: // add
      result = operand2 + rn;
      state->rg[rdIndex] = result;
      if (operand2 > 0 && rn > 0 && result < 0) {
        carry = 1;
      } else if(operand2 < 0 && rn < 0 && result > 0) {
        carry = 1;
      } else {
        carry = 0;
      }
      break;
    case 8: // tst
      result = rn & operand2;
      break;
    case 9: // teq
      result = rn ^ operand2;
      break;
    case 10: // cmp
      result = rn - operand2;
      if (rn < operand2) {
        carry = 0;
      } else {
        carry = 1;
      }
      break;
    case 12: // orr
      result = rn | operand2;
      state->rg[rdIndex] = result;
      break;        
    case 13: // mov
      result = operand2;
      state->rg[rdIndex] = result;
      break;
    default:
      fprintf(stderr, "The opcode is not valid");
      exit(EXIT_FAILURE);
  }
  
  if (getBits(instr, 20, 20)) {
    state->carry = carry;
    state->zero = (result == 0);
    state->neg = (result < 0);
  }
}

int getImmediateProcessing(uint32_t bits, int *carry) {
  uint32_t rotate = getBits(bits, 8, 11);
  uint32_t imm = getBits(bits, 0, 7);
  if (rotate > 0) {
    *carry = getBits(bits, 2 * rotate - 1, 2 * rotate - 1);
  } else {
    *carry = 0;
  }
  return rotateRight(imm, 2 * rotate);
}

int getRegisterProcessing(uint32_t bits, machine const *state, int *carry) {
  uint32_t rmIndex = getBits(bits, 0, 3);
  checkRegisterIndex(rmIndex);
  int rm = state->rg[rmIndex];
  uint32_t shiftType = getBits(bits, 5, 6);
  uint32_t shiftAmount;
  if (getBits(bits, 4, 4)) {
    if (getBits(bits, 7, 7)) {
      fprintf(stderr, "Not a valid instruction!");
      exit(EXIT_FAILURE);
    }
    uint32_t rsIndex = getBits(bits, 8, 11);
    checkRegisterIndex(rsIndex);
    shiftAmount = state->rg[rsIndex];
  } else {
    shiftAmount = getBits(bits, 7, 11);
  }
  return shift(rm, shiftAmount, shiftType, carry);
}

void executeMultiply(uint32_t instr, machine *state) {

  if (getBits(instr, 22, 27) || getBits(instr, 4, 7) != 9) {
    fprintf(stderr, "Not a valid instruction!");
    exit(EXIT_FAILURE);
  }
  
  uint32_t rdIndex = getBits(instr, 16, 19);
  uint32_t rnIndex = getBits(instr, 12, 15);
  uint32_t rsIndex = getBits(instr, 8, 11);
  uint32_t rmIndex = getBits(instr, 0, 3);

  //Check no register index bigger than 12
  checkRegisterIndex(rdIndex);
  checkRegisterIndex(rnIndex);
  checkRegisterIndex(rsIndex);
  checkRegisterIndex(rmIndex);

  int rn = state->rg[rnIndex];
  int rs = state->rg[rsIndex];
  int rm = state->rg[rmIndex];
  
  uint32_t accumulate = getBits(instr, 21, 21);
  int result = rm * rs;
  if (accumulate) {
    result += rn;
  }
  state->rg[rdIndex] = result;
  if (getBits(instr, 20, 20)) {
    state->neg = (result < 0);
    state->zero = (result == 0);
  }
}

void executeTransfer(uint32_t instr, machine *state) {

  bool imm = getBits(instr, 25, 25);
  bool preIndexing = getBits(instr, 24, 24);
  bool upBit = getBits(instr, 23, 23);
  bool loadBool = getBits(instr, 20, 20);

  uint32_t rnIndex = getBits(instr, 16, 19);
  uint32_t rdIndex = getBits(instr, 12, 15);

  uint32_t offset;
  if (imm) {
    // This variable exists just for the reuse of the getRegister from Processing
    int virtualCarry;
    offset = getRegisterProcessing(getBits(instr, 0, 11), state, &virtualCarry);
  } else {
    offset = getBits(instr, 0, 11);
  }
 
  uint32_t rn;
  if (rnIndex != 15) {
    checkRegisterIndex(rnIndex);
    rn = state->rg[rnIndex];
  } else {
    rn = state->pc;
  }
  checkRegisterIndex(rdIndex);

  uint32_t address = rn;
  if (preIndexing) {
    if (upBit) {
      address += offset;
    } else {
      address -= offset;
    }
  }

  if (address / 4 > MEMORY_WORDS) {
    printf("Error: Out of bounds memory access at address 0x%08x\n", address);
    return;
  }

  uint32_t index = address / 4;
  uint32_t remainder = address % 4;
  if (loadBool) {
    uint32_t bitsFromFirst = getBits(state->memory[index], remainder * 8, 31);
    uint32_t bitsFromSecond = 0;
    if (remainder) {
      bitsFromSecond = getBits(state->memory[index + 1], 0, remainder * 8 - 1);
    }
    uint32_t shiftAmount = 32 - remainder * 8;
    if (shiftAmount < 32) {
      bitsFromSecond <<= shiftAmount;
    } else {
      bitsFromSecond = 0;
    }
    state->rg[rdIndex] = bitsFromFirst | bitsFromSecond;
  } else {
    uint32_t firstBits = getBits(state->rg[rdIndex], 0, 31 - 8 * remainder);
    uint32_t secondBits = 0;
    if (remainder) {
      secondBits = getBits(state->rg[rdIndex], 32 - 8 * remainder, 31);
    }

    uint32_t firstMemory = getBits(state->memory[index], 0, 8 * remainder - 1);
    firstBits <<= 8 * remainder;
    state->memory[index] = firstMemory | firstBits;

    uint32_t secondMemory = getBits(state->memory[index + 1], 8 * remainder, 31);
    secondMemory <<= 8 * remainder;
    state->memory[index + 1] = secondMemory | secondBits;
  }

  if (!preIndexing) {
    if (upBit) {
      state->rg[rnIndex] += offset;
    } else {
      state->rg[rnIndex] -= offset;
    }
  }
}

void executeBranch(uint32_t instr, machine *state, optInstr *fetched, decodedInstr *decoded) {
  uint32_t offset = getBits(instr, 0, 23);
  uint32_t sign = getBits(instr, 23, 23);

  offset = offset << 2;

  // Sign extension
  int exOffset = (sign) ? offset | 0x1FF000000 : offset;

  state->pc += exOffset;

  *fetched = (optInstr) {0, false};
  *decoded = (decodedInstr) {-1, NOTHING};
}

bool checkFlags(uint32_t instr, machine const *state) {
  switch(getCond(instr)) {
    case 0:
      return state->zero;
    case 1:
      return !state->zero;
    case 10:
      return state->neg == state->overflow;
    case 11:
      return state->neg != state->overflow;
    case 12:
      return !state->zero && (state->neg == state->overflow);
    case 13:
      return state->zero || (state->neg != state->overflow); 
    case 14:
      return true;
    default:
      fprintf(stderr, "Not a valid condition code!");
      exit(EXIT_FAILURE);  
  }
}

