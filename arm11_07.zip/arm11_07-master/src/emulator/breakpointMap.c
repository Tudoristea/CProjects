#include "../headers/breakpointMap.h"

breakMap newBreakpointMap(void) {
  breakMap m = {NULL, 0};
  return m;
}

bool containsBreakpoint(const breakMap *m, const int line) {
  return lookUpBreakpoint(m, line) != NULL;
}

breakMapNode *lookUpBreakpoint(const breakMap *map, const int line) {
  breakMapNode *node = map->head;
  while (node) {
    if (line == node->key) {
      return node;
    }
    node = node->next;
  }
  return NULL;
}

bool addBreakpoint (breakMap *m, int line, condition *cond) {
  breakMapNode *node = lookUpBreakpoint(m, line);
  if (node) {
    free(node->cond);
    node->cond = cond;
    return false;
  } else {
    breakMapNode *oldHead = m->head;
    breakMapNode *newNode = malloc(sizeof(breakMapNode));
    
    newNode->next = oldHead;
    newNode->key = line;
    newNode->cond = cond;
    
    m->head = newNode;
    m->size++;
    return true;
  }
}
//if we only have one breakpoint per line then we cant have a breakpoint for multiple regsiter values on the same line
//ASS: we cant have multiple breakpoints on the same line
bool deleteBreakpoint (breakMap *m, const int line) {
  breakMapNode *current = m->head, *prev = NULL;

  while (current) {
    if (current->key == line)
    {
      if (prev)
      {
        prev->next = current->next;
      } else {
        m->head = current->next;
      }
      free(current->cond);
      free(current);
      m->size--;
      return true;
    }
    prev = current;
    current = current->next;
  }
  return false;
}

void clearBreakpoints(breakMap *m) {
  breakMapNode *curr = m->head;
  while (curr) {
    breakMapNode *next = curr->next;
    free(curr->cond);
    free(curr);
    curr = next;
  }
}

condition *getBreakpoint (breakMap *map, int line) {
  breakMapNode *node = lookUpBreakpoint(map, line);
  if (node)
  {
    return node->cond;
  } else {
    return NULL;
  }
}
