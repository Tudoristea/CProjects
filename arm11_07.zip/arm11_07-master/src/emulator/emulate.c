#include "../headers/emulate.h"

int main(int argc, char **argv) {
  if (argc != 2) {
    fprintf(stderr, "You have to provide a file!");
    exit(EXIT_FAILURE);
  }

  #ifdef DEBUG //-----------------------------------------------------------

  char *assFile = calloc(strlen(argv[1]) + 3, sizeof(char));
  strcpy(assFile, argv[1]);
  strcat(assFile, ".s");
  FILE *assembly = fopen(assFile, "r");
  free(assFile);
  if (!assembly) {
    perror("The source file cannot be found!");
    exit(EXIT_FAILURE);
  }
  int instrNumber;
  map labels;
  char **instructionArray = instructions(assembly, &instrNumber, &labels);
  fclose(assembly);

  #endif //-----------------------------------------------------------------

  //Initializing the machine
  machine *cpu = (machine *) malloc(sizeof(machine));
  cpu->neg = false;
  cpu->zero = false;
  cpu->carry = false;
  cpu->overflow = false;
  cpu->pc = 0;
  for (int i = 0; i < GEN_REGISTERS; i++) {
    cpu->rg[i] = 0;
  }
  for (int i = 0; i < MEMORY_WORDS; i++) {
    cpu->memory[i] = 0;
  }

  FILE *file = fopen(argv[1], "rb");
  if (!file) {
    perror("The file cannot be read!");
    exit(EXIT_FAILURE);
  }

  /* Loading the binary file into the memory
   * Addresses are stored in Big Endian form
   */
  fread(cpu->memory, sizeof(int), MEMORY_WORDS, file);

  fclose(file);

  #ifdef DEBUG //-----------------------------------------------------------

  printf("Debugging the program %s\n", argv[1]);
  start(cpu, instructionArray, instrNumber, &labels);
  for (int i = 0; i < instrNumber; i++) {
    free(instructionArray[i]);
  }
  free(instructionArray);
  clear(&labels);

  #else //------------------------------------------------------------------

  start(cpu);

  #endif //-----------------------------------------------------------------
  
  free(cpu);

  return EXIT_SUCCESS;
}

#ifdef DEBUG //-------------------------------------------------------------

int instrLine(const map *labels, int instrNo) {
  int instrCount = instrNo;
  mapNode *curr = labels->head;
  while (curr && curr->value <= instrCount) {
    instrCount++;
    curr = curr->next;
  }
  return instrCount; 
}

char **instructions(FILE *file, int *instrNumber, map *m) {
  char buffer[LINE_LENGTH + 1];

  int lines = 0;
  while (fgets(buffer, LINE_LENGTH, file)) {
    lines++;
  }
  rewind(file);

  map labels = newMap();
  uint32_t lineNo = 0;
  char **result = calloc(lines, sizeof(char*));
  int i = 0;
  while (fgets(buffer, LINE_LENGTH, file)) {
    size_t length = strlen(buffer);
    if (buffer[length - 2] == ':') {
      char *key = calloc(length - 1, sizeof(char));
      strncpy(key, buffer, length - 2);
      put(&labels, key, lineNo);
      free(key);
    } else {
      result[i] = calloc(LINE_LENGTH + 1, sizeof(char));
      strncpy(result[i++], buffer, strlen(buffer) - 1);
    }
    lineNo++;
  }
  rewind(file);
  *m = labels;
  *instrNumber = i;
  return result;
}

void printInstructions(char **instructions, const int instrNumber, const map *labels, const optInstr *fetched, 
                      const decodedInstr *decoded, int next) {
  puts("");
  if (decoded->type == BRANCH) {
    char *instr = instructions[decoded->instrNumber];
    int i;
    for (i = strlen(instr) - 1; instr[i] != ' '; i--);
    int labelLine = get(labels, instr + i + 1) + 1;
    printf("Instruction to be executed: (%d) %.*s (%d)\n", instrLine(labels, decoded->instrNumber) + 1, 
          i, instr, labelLine);
  } else if (decoded->type == NOTHING) { 
    puts("No instruction is to be executed!");
  } else {
    printf("Instruction to be executed: (%d) %s\n", instrLine(labels, decoded->instrNumber) + 1, 
          instructions[decoded->instrNumber]);
  }
  if (fetched->isPresent) {
    if (fetched->instrNumber < instrNumber) {
      printf("Instruction to be decoded:  (%d) %s\n", instrLine(labels, fetched->instrNumber) + 1,
            instructions[fetched->instrNumber]);
    } else {
      puts("Instruction to be decoded:  HALT");
    }
  } else {
    puts("No instruction is to be decoded!");
  }
  if (next < instrNumber) {
    printf("Instruction to be fetched:  (%d) %s\n", instrLine(labels, next) + 1, instructions[next]);
  } else {
    puts("Instruction to be fetched:  HALT");
  }
}

void start(machine* state, char **instructions, int instrNumber, const map *labels) {
  optInstr fetched = {0, false};
  decodedInstr decoded = {-1, NOTHING};
  breakMap breakPoints = newBreakpointMap();
  
  // Initialing variables for watch
  bool watchRegs[GEN_REGISTERS + 1];
  int lastValues[GEN_REGISTERS + 4];
  for (int i = 0; i < GEN_REGISTERS; i++){
    watchRegs[i] = false;
    lastValues[i] = state->rg[i];
  }
  watchRegs[GEN_REGISTERS] = false;
  lastValues[GEN_REGISTERS] = state->neg;
  lastValues[GEN_REGISTERS + 1] = state->zero;
  lastValues[GEN_REGISTERS + 2] = state->carry;
  lastValues[GEN_REGISTERS + 3] = state->overflow;
  
  while(getUserInput(&breakPoints, watchRegs, state, NULL, instructions, instrNumber, labels, &fetched, &decoded));
  bool next = false;
  do {
    if (decoded.type != NOTHING) {
      if (next || containsBreakpoint(&breakPoints, decoded.instrNumber)) {
        next = false;
        condition *cond = getBreakpoint(&breakPoints, decoded.instrNumber);
        if (!cond || evaluateCondition(state, cond)) {
          printInstructions(instructions, instrNumber, labels, &fetched, &decoded, state->pc / 4);
          for (int i = 0; i < GEN_REGISTERS; i++) {
            if (watchRegs[i] && lastValues[i] != state->rg[i]) {
              printf("Watchpoint for r%d:\n", i);
              printf("  Old value: %d\n  New value: %d\n", lastValues[i], state->rg[i]);
            }
            lastValues[i] = state->rg[i];
          }
          if (watchRegs[GEN_REGISTERS]) {
            if (lastValues[GEN_REGISTERS] != state->neg) {
              puts("Watchpoint for N:");
              printf("  Old value: %d\n  New value: %d\n", lastValues[GEN_REGISTERS], state->neg);
            }
            if (lastValues[GEN_REGISTERS + 1] != state->zero) {
              puts("Watchpoint for Z:");
              printf("  Old value: %d\n  New value: %d\n", lastValues[GEN_REGISTERS + 1], state->zero);
            }
            if (lastValues[GEN_REGISTERS + 2] != state->carry) {
              puts("Watchpoint for C:");
              printf("  Old value: %d\n  New value: %d\n", lastValues[GEN_REGISTERS + 2], state->carry);
            }
            if (lastValues[GEN_REGISTERS + 3] != state->overflow) {
              puts("Watchpoint for V:");
              printf("  Old value: %d\n  New value: %d\n", lastValues[GEN_REGISTERS + 3], state->overflow);
            }
          }
          lastValues[GEN_REGISTERS] = state->neg;
          lastValues[GEN_REGISTERS + 1] = state->zero;
          lastValues[GEN_REGISTERS + 2] = state->carry;
          lastValues[GEN_REGISTERS + 3] = state->overflow;

          while (getUserInput(&breakPoints, watchRegs, state, &next, instructions, instrNumber, labels, &fetched, &decoded));
        }
      }
      execute(decoded, state, &fetched, &decoded);
    }

    if (fetched.isPresent) {
      decoded = decode(fetched.instruction);
      decoded.instrNumber = fetched.instrNumber;
    }

    fetched = (optInstr) {state->memory[state->pc / 4], true, state->pc / 4};
    state->pc += 4;
  } while (decoded.type != HALT);

  clearBreakpoints(&breakPoints);
  //Printing the result
  puts("\nThe program ended with:");
  printState(state);
}

bool getUserInput(breakMap *breakPoints, bool *watchRegs, machine *state, bool *next, char **instructions, int instrNumber, const map *labels, 
                  const optInstr *fetched, const decodedInstr *decoded) {
  printf("\n> ");
  size_t size = LINE_LENGTH + 1;
  char *com = calloc(size, sizeof(char));
  getline(&com, &size, stdin);

  char *token = strtok(com, " \n");
  if (!token) {
    return true;
  }

  command parsedCommand = parseCommand(token);

  int line, instr, reg;
  switch (parsedCommand) {
    case BREAK:
      token = strtok(NULL, " \n");
      if (!token) {
        puts("No line/label entered!");
        free(com);
        return true;
      }
      else if (isdigit(token[0])) {
        line = strtol(token, NULL, 0);
      } else {
        if (!contains(labels, token)) {
          puts("The label does not exist!");
          free(com);
          return true;
        }
        line = get(labels, token) + 1;
      }
      instr = line - 1;
      instr -= smallerValues(labels, instr);
      if (instr >= 0 && instr < instrNumber) {
        token = strtok(NULL, " \n");
        if (!token || strcmp(token, "if")) {
          printf("Unconditional breakpoint set at line %d\n", line);
          addBreakpoint(breakPoints, instr, NULL);
        } else {
          token = strtok(NULL, "\n");
          condition *cond = parseCondition(token);
          if (!cond) {
            puts("No breakpoint has been set, since the condition is not valid!");
          } else {
            printf("Conditional breakpoint set at line %d\n", line);
            addBreakpoint(breakPoints, instr, cond);
          }
        }
      } else {
        puts("Invalid line number!");
      }
      free(com);
      return true;
    case RUN:
      if (!next) {
        free(com);
        return false;
      }
      puts ("The program is currently running!");
      free(com);
      return true;
    case CONTINUE:
      if (next) {
        free(com);
        return false;
      }
      puts ("The program is not running yet!");
      free(com);
      return true;
    case NEXT:
      if (next) {
        *next = true;
        free(com);
        return false;
      }
      puts ("The program is not running yet!");
      free(com);
      return true;
    case PRINT:
      token = strtok(NULL, " \n");
      if (token && compareStrings(token, "breakpoints")) {
        printBreakpoints(breakPoints);
        free(com);
        return true;
      }
      if (next) {
        if (!token) {
          // If print is called with no argument, then the whole state of the CPU is printed
          printState(state);
        } else {
          if (compareStrings(token, "memory")) {
            printMemory(state->memory);
            puts("");
          } else if (compareStrings(token, "flags")) {
            printf("N: %d\n", state->neg);
            printf("Z: %d\n", state->zero);
            printf("C: %d\n", state->carry);
            printf("V: %d\n", state->overflow);
          } else if (token[0] == 'r' && isdigit(token[1])) {
            reg = strtol(token + 1, NULL, 0);
            if (reg < 0 || reg >= GEN_REGISTERS) {
              puts("Expected a valid register after \'print\'");
            } else {
              printf("Register %d: %d\n", reg, state->rg[reg]);
            }
          } else if (compareStrings(token, "pc") || compareStrings(token, "programcounter")) {
            printf("Program counter: %d\n", state->pc);
          } else {
            puts("Invalid print argument!");
          }
        }
      } else {
        puts ("The program is not running yet!");
      }
      free(com);
      return true;
    case CLEAR:
      clearBreakpoints(breakPoints);
      *breakPoints = newBreakpointMap();
      free(com);
      return true;
    case DELETE:
      token = strtok(NULL, " \n");
      line = strtol(token, NULL, 0);
      instr = line - 1;
      instr -= smallerValues(labels, instr);
      if (deleteBreakpoint(breakPoints, instr)) {
        printf("Breakpoint at line %d has been deleted.\n", line);
      } else {
        printf("No breakpoint at line %d!\n", line);
      }
      free(com);
      return true;
    case SET:
      if (next) {
        token = strtok(NULL, " \n:=");
        if (token && token[0] == 'r') {
          reg = strtol(token + 1, NULL, 0);
          if (reg < 0 || reg >= GEN_REGISTERS) {
            puts("Expected a valid register after \'set\'");
          } else {
            token = strtok(NULL, " \n:=");
            if (token && isdigit(token[0])) {
              int value = strtol(token, NULL, 0);
              state->rg[reg] = value;
              printf("Register %d now contains the value %d.\n", reg, value);
            } else {
              puts("Not a valid value!");
            }
          }
        } else {
          puts("Expected a valid register after \'set\'!");
        }
      } else {
        puts ("The program is not running yet!");
      }
      free(com);
      return true;
    case WATCH:
      token = strtok(NULL, " \n");
      if (token && token[0] == 'r') {
        reg = strtol(token + 1, NULL, 0);
        if (reg < 0 || reg >= GEN_REGISTERS) {
          puts("Expected a valid register after \'watch\'!");
        } else {
          watchRegs[reg] = true;
          printf("Register %d is now being watched.\n", reg);
        }
      } else if (token && compareStrings(token, "flags")) {
        watchRegs[GEN_REGISTERS] = true;
        puts("Flags are being watched!");
      } else {
        printf("Expected a valid register after \'watch\'!");
      }
      free(com);
      return true;
    default:
      puts("Not a valid command!");
      free(com);
      return true;
  }
}

command parseCommand(const char *command) {
  if (compareStrings(command, "break")) {
    return BREAK;
  }
  if (compareStrings(command, "run")) {
    return RUN;
  }
  if (compareStrings(command, "continue")) {
    return CONTINUE;
  }
  if (compareStrings(command, "next")) {
    return NEXT;
  }
  if (compareStrings(command, "set")) {
    return SET;
  }
  if (compareStrings(command, "print")) {
    return PRINT;
  }
  if (compareStrings(command, "delete")) {
    return DELETE;
  }
  if (compareStrings(command, "clear")) {
    return CLEAR;
  }
  if (compareStrings(command, "watch")){
    return WATCH;
  }
  return INVALID;
}

bool compareStrings (const char *shortCommand, const char *longCommand) {
  for (int i = 0; shortCommand[i]; i++) {
    if (!longCommand[i] || longCommand[i] != tolower(shortCommand[i])) {
      return false;
    }
  }
  return true;
}

bool evaluateCondition(machine *state, condition *cond) {
  int regVal = state->rg[cond->reg];
  switch(cond->operator) {
    case G:
      return regVal > cond->immediate;
    case GE:
      return regVal >= cond->immediate;
    case E:
      return regVal == cond->immediate;
    case L:
      return regVal < cond->immediate;
    case LE:
      return regVal <= cond->immediate;
    case NE:
      return regVal != cond->immediate;
    default:
      fprintf(stderr, "Invalid operator");
      return false;
  }
}

condition* parseCondition(char *str) {
  if (str[0] != 'r') {
    return NULL;
  }
  char *next;
  op operator;
  int imm;
  int reg = strtol(str + 1, &next, 0);
  if (reg < 0 || reg > 12) {
    return NULL;
  }
  for (; *next && *next == ' '; next++);
  if (!*next) {
    return NULL;
  }
  switch(next[0]) {
    case '<':
      if (next[1] == '=') {
        operator = LE;
        next++;
      } else {
        operator = L;
      }
      break;
    case '>':
      if (next[1] == '=') {
        operator = GE;
        next++;
      } else {
        operator = G;
      }
      break;
    case '!':
      if (next[1] != '=') {
        return NULL;
      }
      operator = NE;
    case '=':
      operator = E;
      if (next[1] == '=') {
        next++;
      }
      break;
    default:
      return NULL;
  }
  next++;
  for (; *next && *next == ' '; next++);
  if (!isdigit(next[0])) {
    return NULL;
  }
  imm = strtol(next, NULL, 0);
  condition *cond = malloc(sizeof(condition));
  cond->immediate = imm;
  cond->operator = operator;
  cond->reg = reg;
  return cond;
}

char* opRepresentation(op oper) {
  switch(oper) {
    case LE:
      return "<=";
    case L:
      return "<";
    case E:
      return "=";
    case NE:
      return "!=";
    case G:
      return ">";
    case GE:
      return ">=";
    default:
      fprintf(stderr, "Invalid operator");
      return " ";       
  }
}

void printBreakpoints(breakMap *breakPoints) {
  breakMapNode *curr = breakPoints->head;
  if (breakPoints->size) {
    printf("Currently there are %lu breakpoints set:\n", breakPoints->size);
    while (curr) {
      if (curr->cond) {
      printf("\tConditional breakpoint at line %d, if r%d %s %d\n", curr->key, curr->cond->reg,
            opRepresentation(curr->cond->operator), curr->cond->immediate);
      } else {
        printf("\tUnconditional breakpoint at line %d\n", curr->key);
      }
      curr = curr->next;
    }
  } else {
    puts("Currently there are no breakpoints set.");
  }
}

#else //--------------------------------------------------------------------

void start(machine* state) {
  optInstr fetched = {0, false};
  decodedInstr decoded = {-1, NOTHING};
  do {
    if (decoded.type != NOTHING) {
      execute(decoded, state, &fetched, &decoded);
    }
    if (fetched.isPresent) {
      decoded = decode(fetched.instruction);
    }
    fetched = (optInstr) {state->memory[(state->pc) / 4], true};
    state->pc += 4;
  } while (decoded.type != HALT);

  //Printing the result
  printState(state);
}

#endif //-------------------------------------------------------------------

decodedInstr decode(int instr) {
  if (instr == 0) {
    return (decodedInstr) {0, HALT};
  }
  switch(getId(instr)) {
    case 0: // Data Processing or Multiply
      if (isMul(instr)) {
        return (decodedInstr) {instr, MULTIPLY};
      }
      return (decodedInstr) {instr, DATA_PROCESSING};
    case 1: // Single Data Transfer
      return (decodedInstr) {instr, DATA_TRANSFER};
    case 2: // Branch
      return (decodedInstr) {instr, BRANCH};
    default:
      fprintf(stderr, "Not a valid instruction id!");
      exit(EXIT_FAILURE);
  }
}
