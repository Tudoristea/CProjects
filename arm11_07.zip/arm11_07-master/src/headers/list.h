#include <stdlib.h>

#ifndef LIST
#define LIST

typedef struct node {
    int val;
    struct node *next;
} node;

typedef struct linkedList {
    node *head;
    int size;
} linkedList;

void add(linkedList *list, int item);

int getItem(linkedList *list);

#endif
