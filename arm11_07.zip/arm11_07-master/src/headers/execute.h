#include "headers.h"
#include "utils.h"

// Executed a decoded instruction, possibly chaning the state of the machine and the pipeline
void execute(decodedInstr instr, machine *state, optInstr *fetched, decodedInstr *decoded);

// The specific execute method for the process data instruction
void executeProcessing(uint32_t instr, machine *state);

// Returns the operand2 from the first 12 bits (when I = 1)
int getImmediateProcessing(uint32_t bits, int *carry);

// Returns the operand2 from the first 12 bits (when I = 0)
int getRegisterProcessing(uint32_t bits, machine const *state, int *carry);

// The specific execute method for the multiply instruction
void executeMultiply(uint32_t instr, machine *state);

// The specific execute method for the transferr data instruction
void executeTransfer(uint32_t instr, machine *state);

// The specific execute method for the branch instruction
void executeBranch(uint32_t instr, machine *state, optInstr *fetched, decodedInstr *decoded);

// Checks that the conditions succeed (or is al)
bool checkFlags(uint32_t instr, machine const *state);
