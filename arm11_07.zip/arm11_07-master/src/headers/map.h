#include "headers.h"

#ifndef MAP
#define MAP

//-------------Type_Declarations-------------

typedef struct mapNode mapNode;
typedef struct map map;

struct mapNode {
  mapNode *next;
  char *key;
  int value;
};

struct map {
  mapNode *head;
  size_t size;
};

//-------------Map_Functions----------------

// Creates and returns a new map, with a NULL head and size 0
map newMap(void);

/* 
 * Returns the value associated to the given key,
 *   from the given map
 * Throws an error message if the key is not in the map
 */ 
int get(const map *m, const char *key);

// Returns true if the key is contained in the map
bool contains(const map *m, const char *key);

 /* 
  * Returns the Node with the given key, from the given map
  * Returns NULL if there is no node with the given key
  */
mapNode* lookUp(const map *m, const char *key);

// Puts the key and the value into the map
void put(map *m, const char *key, int value);

// Prints the map in 2 columns
void printMap(const map *m);

// Clears the memory allocated for the map
void clear(map *m);

// Returns the number of nodes with the key smaller than x
int smallerValues(const map *m, int x);

#endif
