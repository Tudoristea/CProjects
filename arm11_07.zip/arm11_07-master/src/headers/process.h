#include "headers.h"
#include "constMaps.h"
#include "list.h"
#include "utils.h"

#define DELIM ", "

// Process a Data Processing Instruction
uint32_t processDataProcessing(char *instr);

// Parses register from the string reg
uint32_t getRegister(char* reg);

// Process a Multiply Instruction
uint32_t processMultiply(char *instr);

// Process a Data Transfer Instruction
uint32_t processDataTransfer(char *instr, uint32_t address, uint32_t *lastAddress, struct linkedList *list);

// Process a Branch Instruction
uint32_t processBranch(char *instr, map *labels, uint32_t address);

// Process a Shift Instruction
uint32_t processShift(char *instr);
