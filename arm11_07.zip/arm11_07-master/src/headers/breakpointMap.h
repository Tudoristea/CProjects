#include "headers.h"

typedef enum {
    G,  // >
    GE, // >=
    E,  // ==
    LE, // <=
    L,  // <
    NE  // !=
} op;

typedef struct {
    int reg;
    int immediate;
    op operator;
} condition;

typedef struct breakMapNode breakMapNode;

//cant make a pointer 
struct breakMapNode {
  breakMapNode *next;
  int key;
  condition *cond;//should this be a pointer or is this fine
};

typedef struct {
  breakMapNode *head;
  size_t size;
} breakMap;

//-------------Map_Functions----------------

// Creates and returns a new Breakpoint map, with a NULL head and size 0
breakMap newBreakpointMap(void);

//Returns true if the line has a breakpoint associated with it
//Doesn't check that a breakpoint exists with the right values, just looks at the line
bool containsBreakpoint(const breakMap *m, const int line);

/* 
 * Returns the Node associated with the given line, from the given map
 * Returns NULL if there is no node with the given key
 */
breakMapNode *lookUpBreakpoint(const breakMap *map, const int line) ;

//returns false if the line already has a breakpoint associated with it else
//adds the breakpoint with the corresponding values and returns true
//Doesn't check line is in bounds?
//Doesn't have an option for non conditional breakpoints
bool addBreakpoint (breakMap *m, int line, condition *cond);

//returns false if the line doesn't have a breakpoints else deletes the breakpoint
//and returns true;
bool deleteBreakpoint (breakMap *m, const int line);

//clears all breakpoints and frees the memory taken up by them
void clearBreakpoints(breakMap *m);

//Gets the condition associated with the given line in the given map
condition *getBreakpoint (breakMap *map, int line);

