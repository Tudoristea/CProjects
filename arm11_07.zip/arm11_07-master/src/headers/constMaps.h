#include "headers.h"
#include "map.h"

// Global Maps
map INSTRUCTION_MAP, OPCODE_MAP, SHIFT_MAP, CONDITION_MAP;

// Initializes the global maps, using the corresponding functions
void createAllMaps(void);

// Clears all the global maps
void clearAllMaps(void);
