#include "headers.h"

/* Returns the bits between lastBit and firstBit from the instruction
 * Pre: firstBit <= lastBit
 */
uint32_t getBits(uint32_t instruction, int firstBit, int lastBit);

/* Returns the condition - bits 28 to 31
 * Uses the getBits function
 */
uint32_t getCond(uint32_t instruction);

/* Returns the id - bits 26 and 27
 * Uses the getBits function
 */
uint32_t getId(uint32_t instruction);

/* Return true if the instruction is Multiply
 * (Whether Multiply or Data Processing)
 * NOT FINAL BY ANY MEANS - NOT SURE IT CONVERS ALL CASES!!!
 */
bool isMul(uint32_t instruction);

// Converts an instruction from big endian to little endian - NOT DONE YET
uint32_t convertToLittleEndian(uint32_t instruction);

// Rotates right the value by the rotation
int rotateRight(uint32_t value, uint32_t rotation);

// Exits the program, if the index is not a valid index position (>12)
void checkRegisterIndex(uint32_t index);

// Shifts the value by shiftAmount, according to shiftType
int shift(int value, uint32_t shiftAmount, uint32_t shiftType, int *carry);

// Prints the current state of the machine
void printState(const machine *state);

// Prints the memory of the machine (callled by printState) IN BIG ENDIAN
void printMemory(const int memory[]);

// Converts the flags to a register
int transformCPSR(const machine *state);

// Rotates left with 2 positions the value stored in the pointer
void rotateLeft(uint32_t *value);
