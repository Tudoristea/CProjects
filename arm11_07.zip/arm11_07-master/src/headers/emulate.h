#include <ctype.h>
#include "headers.h"
#include "execute.h"
#include "utils.h"

#ifdef DEBUG

#include "map.h"
#include "breakpointMap.h"

#define LINE_LENGTH 511

typedef enum {
  INVALID,
  BREAK, 
  RUN, 
  CONTINUE,
  NEXT,
  SET,
  PRINT,
  CLEAR,
  DELETE,
  WATCH
} command;

// Given the label map and the instruction number in memory, returns the line number
int instrLine(const map *labels, int instrNo);

// Prints the 3 instructions in the pipeline
void printInstructions(char **instructions, int instrNumber, const map *labels, 
                      const optInstr *fetched, const decodedInstr *decoded, int next);

// Returns an array with all the instructions in the heap
char **instructions(FILE *file, int *instrNumber, map *m);

// The start of a program (already loaded into memory)
void start(machine* state, char **instructions, int instrNumber, const map *labels);

// Gets user input at the beginning of the execution and when a breakpoint is encountered
bool getUserInput(breakMap *breakPoints, bool *watchRegs, machine *state, bool *step, char **instructions, int instrNumber, 
                  const map *labels, const optInstr *fetched, const decodedInstr *decoded);

// Parses the user command
command parseCommand(const char *command);

// Checks if longCommand starts with shortCommand
bool compareStrings (const char *shortCommand, const char *longCommand);

// Given the CPU state, it evaluates the truth value of the cond
bool evaluateCondition(machine *state, condition *cond);

// Parses a condition and returns it heap allocated
condition* parseCondition(char *str);

// Given operator, returns its string representation
char* opRepresentation(op oper);

// Prints all the breakpoints
void printBreakpoints(breakMap *breakPoints);

#else

// The start of a program (already loaded into memory)
void start(machine* state);

#endif

// Decodes an instruction
decodedInstr decode(int instr);
