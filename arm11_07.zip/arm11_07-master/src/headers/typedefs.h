#ifndef TYPES
#define TYPES

#define MEMORY_WORDS 16384
#define GEN_REGISTERS 13

//Struct to capture the state of the processor
typedef struct machine {
  bool neg;
  bool zero;
  bool carry;
  bool overflow;
  int pc;
  int rg[GEN_REGISTERS];
  int memory[MEMORY_WORDS];
} machine;

//Types of instruction
typedef enum instrType {
  DATA_PROCESSING,
  MULTIPLY,
  DATA_TRANSFER,
  BRANCH,
  HALT,
  NOTHING,
  SHIFT
} instrType;

typedef struct decodedInstr {
  uint32_t instruction;
  instrType type;
  uint32_t instrNumber;
} decodedInstr;

typedef struct optIntstr {
  uint32_t instruction;
  bool isPresent;
  uint32_t instrNumber;
} optInstr;

#endif
