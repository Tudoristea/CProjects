#include "headers.h"
#include "map.h"
#include "constMaps.h"
#include "process.h"

#define LINE_LENGTH 511

/* 
 * Returns a map containing labels and their addresses
 * Returns through the pointer lastAddress the last address
 */
map makeLabelMap(FILE *file, uint32_t *lastAddress);

/* 
 * Goes through the assembly file
 * Writes instructions in the binary file using the label map
 */
void makeBinaryFile(FILE *assembly, FILE *bin, map *labels, uint32_t *lastAddress);
