#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* 
 * Program that will get some commands, specified by the
 * arguments of main (how many commands, size of a command(in chars))
 * and then paste them in the stdout.
 * PLUS some pointer arithmetic
 * Easy project, was good for understanding pointers of pointers (String pointers)
 */

// ------------------HELPER FUNCTIONS------------------


//Creats space in heap for one command
char *createCommand(size_t size) {
  return (char *) malloc((size) * sizeof(char));
}

//Creates space in heap for n commands
//Uses "createCommand"
char **createCommands(int n) {
  return (char **) calloc(n, sizeof(char *));
}

//Gets one command from stdin
char *getCommand(size_t size) {
  char *newCommand = createCommand(size);
  printf("> ");
  if (!fgets(newCommand, size, stdin)) {
    fprintf(stderr, "Error reading command.\n");
    exit(EXIT_FAILURE);
  }
  char *pos;
  pos = strchr(newCommand, '\n');
  *pos = '\0';
  return newCommand;
}

//Gets n commands from stdin
//Uses "getCommand"
char **getCommands(int n, size_t size) {
  char **newCommandsP = createCommands(n);
  for (int i = 0; i < n; i++) {
    *(newCommandsP + i) = getCommand(size);
  }
  return newCommandsP;
}

//Prints n commands
void printCommands(char **commands, int n) {
  for (int i = 0; i < n; i++) {
    printf("Executed: %s\n", *(commands + i));
  }
}

//Frees the given space in the heap for n commands
void freeCommands(char **commands, int n) {
  for (int i = 0; i < n; i++) {
    free(*(commands + i));
  }
  free(commands);
}

// ------------------POINTER ARITHMETIC------------------

//Returns the length of a string + (required) the \0 char
int stringLength(char *string) {
  char *charP = string;
  int i = 0;
  for( i = 0; *(charP + i) != '\0';) {
    i++;
  }
  return ++i;
}

//Returns strcat(string1, string2)
char *stringCat(char *string1, char *string2) {
  int newStringLen = stringLength(string1) + stringLength(string2);
  char *charP = calloc(newStringLen, sizeof(char));
  for (int i = 0; i < stringLength(string1) - 1; i++) {
    *(charP + i) = *(string1 + i); 
  }
  for (int i = 0; i < stringLength(string2); i++) {
    *(charP + i + stringLength(string1) - 1) = *(string2 + i); 
  }
  return charP;
}

//Prints the length of all the commands
void printCommandLengths(char **commands, int n) {
  for (int i = 0; i < n; i++) {
    char *currentString = *(commands + i);
    printf("The command you introduced, %s, has length: %d\n", currentString, stringLength(currentString));
  }
}

//Prints the concatanation of all the commands
void printCommandConcat(char **commands, int n) {
  char *commandA = *commands;
  char *commandB = NULL;
  for (int i = 1; i < n; i++) {
    commandB = *(commands + i);
    commandA = stringCat(commandA, commandB);
  }
  printf("The cat of all commands is: %s\n", commandA);
}




// ---------------------MAIN FUNCTION--------------------

int main(int argc, char **argv) {
  int n = atoi(*(argv + 1));
  size_t size = atoi(*(argv + 2));
  char **myCommands = getCommands(n, size);
  printCommands(myCommands, n);
  printCommandLengths(myCommands, n);
  printCommandConcat(myCommands,n);
  freeCommands(myCommands, n);

  char *enteredString = calloc(50, sizeof(char));
  printf("Enter a word: ");
  if(!fgets(enteredString, 50, stdin)) {
    fprintf(stderr, "Error reading word.\n");
    exit(EXIT_FAILURE);
  }
  char *pos;
  pos = strchr(enteredString, '\n');
  *pos = '\0';

  char *enteredString2 = calloc(50, sizeof(char));
  printf("Enter a word: ");
  if(!fgets(enteredString2, 50, stdin)) {
    fprintf(stderr, "Error reading word.\n");
    exit(EXIT_FAILURE);
  }
  pos = strchr(enteredString2, '\n');
  *pos = '\0';

  char *enteredStringConcat = stringCat(enteredString,enteredString2);
  printf("The string concatanation of %s and %s is: %s\n", enteredString, enteredString2, enteredStringConcat);
  printf("The length of \"%s\" + the \\0 character is: %d\n",enteredString, stringLength(enteredString));
  printf("The length of \"%s\" + the \\0 character is: %d\n",enteredString2, stringLength(enteredString2));
  printf("The length of \"%s\" + the \\0 character is: %d\n",enteredStringConcat, stringLength(enteredStringConcat));
  
  return 0;
}

