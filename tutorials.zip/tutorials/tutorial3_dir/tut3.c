#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

// -----------------------BIT OPERATIONS-----------------------


// #define FIRST_16_BITS 4294901760
#define LAST_16_BITS 65535

// Prints the first 32 bits of a number
// Shifts number
void printBits32(uint32_t x) {
  int i;
  uint32_t mask = 1 << 31;
  for(i=0; i<32; ++i) {
    if (i == 16) {
      printf(" ");
    }
    if((x & mask) == 0){
      printf("0");
    }
    else {
     printf("1");
    }
   x = x << 1;
  }
  printf("\n");
}

// Prints the first 16 bits of a number
// Shifts mask
void printBits16(uint16_t x) {
  int i;
  uint16_t mask = 1 << 15;
  for(i=0; i<16; ++i) {
    if((x & mask) == 0){
      printf("0");
    }
    else {
     printf("1");
    }
   mask = mask >> 1;
  }
  printf("\n");
}

// Assigns to first the first 16 bits of the x value
// Assigns to last the last 16 bits of the x value
void assign(uint32_t x, uint16_t *first, uint16_t *second) {
 *first = (x >> 16) & LAST_16_BITS;
 printBits16(*first);
 *second = x & LAST_16_BITS;
 printBits16(*second);
}

// Exactly like printBits16 but for signed ints
// Produces a warning regarding the implicit conversions
void printSBits16(int16_t x) {
  int i;
  int16_t mask = 1 << 15; // <- Warning here
  for(i=0; i<16; ++i) {
    if((x & mask) == 0){
      printf("0");
    }
    else {
     printf("1");
    }
   mask = mask >> 1;
  }
  printf("\n");
}

// -------------------------STRUCT-------------------------

// Used this to eliminate magic numbers
#define NO_NAME_LETTERS 40

typedef struct person {
 char name[NO_NAME_LETTERS];
 int age;
} person_t;

// Reads from stdin the name and age of a new person
// Returns a pointer to the newly created person
// The name has to have less than 40 characters
person_t *getPerson(void) {
  person_t *newPerson;
  if(!(newPerson = malloc(sizeof(person_t)))) {
    fprintf(stderr, "Could not assign memory!\n");
    exit(EXIT_FAILURE);
  }
  printf("Write a name for your person: ");
  if(!fgets(newPerson->name, NO_NAME_LETTERS, stdin)) {
    fprintf(stderr, "Could not read name!");
    exit(EXIT_FAILURE);
  }
  char *pos;
  pos = strchr(newPerson->name, '\n');
  *pos = '\0';
  printf("Write an age for your person: ");
  scanf("%d", &(newPerson->age));
  printf("Thank you! Person done!\n");
  return newPerson;
}
// For ease of reading
#define PersonFromPosI (*(arrOfPers + i))

// Prints the number in the given array, name and age of a person
void printPeople(person_t **arrOfPers, int  noPers) {
  for(int i = 0; i < noPers; i++) {
    printf("%d: The person %s is %d years old\n", i, PersonFromPosI->name, PersonFromPosI->age);
  }
}

// --------------------------MAIN--------------------------

int main(int argc, char **argv) {
  printBits32(atoi(*(argv + 1)));
  uint16_t *first, *second;
  first = malloc(sizeof(uint16_t));
  second = malloc(sizeof(uint16_t));

  if (!first || !second) {
    fprintf(stderr, "Could not allocate memory!");
    return EXIT_FAILURE;
  }
  assign(atoi(*(argv + 1)), first, second);

// Demonstrate how values are affected by the same 
// pointer value held in 2 pointers
  int16_t *signedFirst = (int16_t *) first;
  printf("%d, %d\n", *signedFirst, *first);
  *first = *first << 1;
  printf("%d, %d\n", *signedFirst, *first);
  printSBits16(*signedFirst); 
  printBits16(*first);
// We get some warnings regarding the implicit conversion in 
// printSBits16, telling us exactly what we were looking for
// Watch out: if compiled with the -Werror flag this will not work

  int noPers = -1;
  printf("How many people do you wish to input? ");
  scanf("%d", &noPers);
  if(noPers == -1) {
    fprintf(stderr, "COuld not read/introduced illegal number!");
    return EXIT_FAILURE;
  }
  person_t *myPers[noPers];
  for(int i = 0; i < noPers; i++) {
    myPers[i] = getPerson();
  }
  printPeople(myPers, noPers);

  return 0;
}